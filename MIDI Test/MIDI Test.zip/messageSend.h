#pragma once

void sendMessage(std::string message, std::string title = "Message");
