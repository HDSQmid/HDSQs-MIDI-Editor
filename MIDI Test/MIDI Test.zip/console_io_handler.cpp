#include "stdafx.h"
#include "console_io_handler.h"
#include "messageSend.h"

#define NUM_HANDLERS 6
ConsoleQuit quit;
ConsoleHelp help;
ConsoleFileOpen openFile;
ConsoleFileClose closeFile;
ConsoleFileSave saveFile;
ConsoleFileSaveAs saveFileAs;

consoleInputHandler* input_handlers[NUM_HANDLERS] = { &help, &quit, &openFile, &closeFile, &saveFile, &saveFileAs };

void handleConsoleInput(std::string input)
{

	std::string test;
	std::istringstream iss{ input };
	iss >> test;

	std::ostringstream oss;
	oss << iss.rdbuf();

	std::string args = oss.str();
	if(args != "") args = args.substr(1);

	//remove command from rest of arguments for easier processing

	bool foundCall = 0; // bool for whether a handler was found
	for (int i = 0; i < NUM_HANDLERS; i++) {
		if (input_handlers[i]->getIdentifier() == test) {
			input_handlers[i]->call(args);
			foundCall = 1;
			break;
		}
	}

	if (!foundCall) sendMessage("Didn't find a matching command", "Error");

}

/***************************************/

void consoleInputHandler::call(std::string args)
{

	std::cout << "Test" << std::endl;

}

std::string consoleInputHandler::getIdentifier()
{
	return identifier;
}

/***************************************/

consoleInputHandler::consoleInputHandler()
{
	identifier = "NULL";
}

ConsoleFileOpen::ConsoleFileOpen()
{
	identifier = "open";
}

void ConsoleFileOpen::call(std::string args)
{
	if (args == "") {

		sendMessage("Expected a file name", "Error");
		return;

	}
	
	fileOpen(args);

	return;
}

ConsoleFileClose::ConsoleFileClose()
{
	identifier = "close";
}

void ConsoleFileClose::call(std::string args)
{
	if (currentFile == NULL) // if file is not open
	{
		sendMessage("There aren't any open files", "Error");
		return;

	}
	
	fileClose();
}

ConsoleFileSave::ConsoleFileSave()
{
	identifier = "save";

}

void ConsoleFileSave::call(std::string args)
{
	if (currentFile == NULL) // if file is not open
	{
		sendMessage("There aren't any open files", "Error");
		return;

	}

	if (args != "") currentFile->saveAs(args);

	else currentFile->save();
}

ConsoleFileSaveAs::ConsoleFileSaveAs()
{
	identifier = "saveas";
}

void ConsoleFileSaveAs::call(std::string args)
{
	if (currentFile == NULL) // if file is not open
	{
		sendMessage("There aren't any open files", "Error");
		return;

	}

	currentFile->saveAs(args);
}

ConsoleQuit::ConsoleQuit()
{
	identifier = "quit";
}

void ConsoleQuit::call(std::string args)
{
	exit(0);
}

ConsoleHelp::ConsoleHelp()
{
	identifier = "help";
}

void ConsoleHelp::call(std::string args)
{
	std::cout << "Help:\n" <<
		"open - opens a file\n" <<
		"save - saves an open file, include a new file name to save as\n" <<
		"close - closes the current file\n" <<
		"quit - quits the program after saving files\n" << std::endl;

}
