#include "stdafx.h"
#include "messageSend.h"

void sendMessage(std::string message, std::string title)
{
#ifdef CONSOLE
	std::cout << title << ": \t\t" << message << std::endl;
	
#endif // 


}
